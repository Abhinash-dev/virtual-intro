const mongoose=require("mongoose");
const DB="mongodb+srv://abhi:abhinash@cluster0.wa5dl.mongodb.net/GYMDB?retryWrites=true&w=majority"
console.log(DB);
mongoose.connect(DB,{
    useNewUrlParser:true,
   
    useUnifiedTopology:true,
  
}).then(()=>{
    console.log("connection successful");
}).catch((err)=>console.log("no connect",err));
