const mongoose=require("mongoose");

const DataSchema=new mongoose.Schema({
    fullname:String,
    email:String,
    phone:Number,
    age:Number,
    address:String,
    gender:String,
    
})

module.exports=mongoose.model("User",DataSchema);