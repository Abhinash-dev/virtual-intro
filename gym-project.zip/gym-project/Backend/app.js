const express=require("express");
const app=express();
const cors=require("cors");
app.use(cors());
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
const userController = require('./controller/userController');
const port = process.env.PORT || '5000';
app.post('/signup',userController.userSignup)

app.listen(port, () => {
    console.log(`Listening to requests on http://localhost:${port}`);
  });