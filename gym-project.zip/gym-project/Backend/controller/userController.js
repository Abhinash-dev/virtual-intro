require('../utils/DBconnect');
const User = require('../model/user');

const userSignup = async (req, res, next) => {
    try {
        console.log(req.body)
        const fullname = req.body.fullname ? req.body.fullname.toString() : '';
        const email = req.body.email ? req.body.email.toString() : '';
        const phone = req.body.phone ? req.body.phone.toString() : '';
        const age = req.body.age ? req.body.age.toString() : '';
        const address = req.body.address ? req.body.address.toString() : '';
        const gender = req.body.gender ? req.body.gender.toString() : '';
       

        if (!fullname || !email || !gender || !age || !phone || !address) {
            return res.status(422).json({
                message: "missing fields are required",
                error: true
            });
        }

        const userExist = await User.findOne({
            email:email
        });

        if (userExist) {
            return res.status(200).json({
                message: "Email is Already exist",
                error: true
            });
        } else {
            const user = new User({
                fullname,
                email,
                age,
                phone,
                address,
                gender
              
               
            });
            user.save(function (err, doc) {
                if (!err) {
                    res.status(200).json({
                        message: "Successfull",
                        error: false,
                        data: doc
                    });
                   
                } else {
                    res.status(500).json({
                        message: 'Error in save data',
                        error: true
                    });
                }
            });
        }
    } catch (err) {
        res.status(500).json({
            message: 'Something went wrong',
            error: true
        });
    }
}

module.exports = {
    userSignup
    
};